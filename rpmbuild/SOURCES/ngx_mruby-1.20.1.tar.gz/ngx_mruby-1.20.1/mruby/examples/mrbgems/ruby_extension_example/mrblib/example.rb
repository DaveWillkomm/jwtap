class RubyExtension
  def RubyExtension.ruby_method
    puts "A Ruby Extension"
  end
end

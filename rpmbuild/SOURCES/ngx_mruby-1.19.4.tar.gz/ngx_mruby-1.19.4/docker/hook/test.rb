Nginx.echo "This is test for ngx_mruby"

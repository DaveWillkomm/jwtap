Nginx::Request.new.headers_out["x-add-new-header"] = "new_header"

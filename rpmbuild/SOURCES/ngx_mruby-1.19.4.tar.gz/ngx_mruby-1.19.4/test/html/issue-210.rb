Nginx::Request.new.headers_out["fuga"] = "hoge"

r = Nginx::Request.new

r.var.fuga.to_i * 2

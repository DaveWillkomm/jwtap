# Example
```bash
cp set.rb set2.rb unified_hello.rb ${DOCROOT}/.
cp nginx.conf ${NGINX_CONF_DIR}/.
```
access some locations in nginx.conf
